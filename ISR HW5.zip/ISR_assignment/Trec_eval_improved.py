from collections import OrderedDict
import math
import sys

relevanceJudgements = {}

def retrieveQueryResults(rankList):
    """Parse rankList.txt to get ranked documents per query"""
    queryResults = OrderedDict()
    
    with open(rankList, 'r') as f:
        for line in f:
            items = line.strip().split()
            if len(items) < 4:
                continue
            
            queryID = items[0]
            documentID = items[2]
            
            if queryID in queryResults:
                queryResults[queryID].append(documentID)
            else:
                queryResults[queryID] = [documentID]
    
    return queryResults

def getRelevanceJudgements(qrel):
    """Parse qrels.txt to get relevant documents per query"""
    global relevanceJudgements
    relevanceJudgements = {}
    
    with open(qrel, 'r') as f:
        for line in f:
            cols = line.strip().split()
            if len(cols) < 4:
                continue
            
            queryID = cols[0]
            documentID = cols[2]
            relevance = cols[3].strip()
            
            if relevance == '1':
                if queryID in relevanceJudgements:
                    relevanceJudgements[queryID].append(documentID)
                else:
                    relevanceJudgements[queryID] = [documentID]
    
    print(f"Loaded relevance for {len(relevanceJudgements)} queries")

def designateVals(lst, val, rank):
    """Store metric values by rank"""
    if rank in lst:
        lst[rank].append(val)
    else:
        lst[rank] = [val]
    return lst

def printMeanVals(lst, desc, kVals=[], qid=''):
    """Print mean values for metrics"""
    if not kVals:
        if len(lst) == 0:
            print(f"{desc}: 0.0000")
        else:
            print(f"{desc}: {math.fsum(lst) / len(lst):.4f}")
    else:
        for k in kVals:
            if k in lst and len(lst[k]) > 0:
                val = math.fsum(lst[k]) / len(lst[k])
            else:
                val = 0.0
            
            if qid != '':
                print(f"{desc}{k} for {qid}: {val:.4f}")
            else:
                print(f"{desc}{k}: {val:.4f}")

def calculateMetrics(queryResults, verbose=False):
    """Calculate all evaluation metrics"""
    kVals = [5, 10, 20, 50, 100]
    
    AP, RP, NDCG = [], [], []
    P, R, F1 = {}, {}, {}
    
    # Open detailed output file
    with open("evaluation_details.txt", 'w') as detail_file:
        detail_file.write("QueryID\tDocumentID\tRank\tRelevant\tPrecision\tRecall\n")
        
        for queryID in queryResults:
            if queryID not in relevanceJudgements:
                if verbose:
                    print(f"Query {queryID}: No relevance judgments found, skipping")
                continue
            
            relevantDocuments = relevanceJudgements[queryID]
            results = queryResults[queryID]
            
            relevantNumber = 0
            psum = 0
            rp = 0
            relevanceScore = []
            
            for rank, document in enumerate(results, start=1):
                isRelevant = 1 if document in relevantDocuments else 0
                
                if isRelevant:
                    relevantNumber += 1
                
                if rank <= len(relevantDocuments):
                    rp = relevantNumber
                
                precision = relevantNumber / rank
                recall = relevantNumber / len(relevantDocuments) if len(relevantDocuments) > 0 else 0
                
                if isRelevant:
                    psum += precision
                
                if rank in kVals:
                    P = designateVals(P, precision, rank)
                    R = designateVals(R, recall, rank)
                    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
                    F1 = designateVals(F1, f1, rank)
                
                relevanceScore.append(isRelevant)
                
                # Write to details file
                detail_file.write(f"{queryID}\t{document}\t{rank}\t{isRelevant}\t{precision:.4f}\t{recall:.4f}\n")
            
            # Calculate DCG and nDCG
            dc_value = 0.0
            for j, score in enumerate(relevanceScore):
                dc_value += score / math.log(j + 2)
            
            ideal = sorted(relevanceScore, reverse=True)
            idc_value = 0.0
            for j, score in enumerate(ideal):
                idc_value += score / math.log(j + 2)
            
            ndcg = dc_value / idc_value if idc_value > 0 else 0
            NDCG.append(ndcg)
            
            rPrecision = rp / len(relevantDocuments) if len(relevantDocuments) > 0 else 0
            RP.append(rPrecision)
            
            avgPrecision = psum / len(relevantDocuments) if len(relevantDocuments) > 0 else 0
            AP.append(avgPrecision)
            
            if verbose:
                print(f"\nQuery {queryID}")
                print(f"  Relevant documents: {len(relevantDocuments)}")
                print(f"  Retrieved documents: {len(results)}")
                print(f"  Average Precision: {avgPrecision:.4f}")
                print(f"  R-Precision: {rPrecision:.4f}")
                print(f"  nDCG: {ndcg:.4f}")
    
    # Print summary
    print("\n" + "=" * 60)
    print("EVALUATION RESULTS SUMMARY")
    print("=" * 60)
    
    print(f"\nMAP (Mean Average Precision): {math.fsum(AP) / len(AP):.4f}" if AP else "MAP: 0.0000")
    print(f"Average R-Precision: {math.fsum(RP) / len(RP):.4f}" if RP else "Average R-Precision: 0.0000")
    print(f"Average nDCG: {math.fsum(NDCG) / len(NDCG):.4f}" if NDCG else "Average nDCG: 0.0000")
    
    print("\n" + "-" * 60)
    print("Metrics at K (Averaged over all queries)")
    print("-" * 60)
    print(f"{'K':<10} {'Precision@K':<15} {'Recall@K':<15} {'F1@K':<15}")
    print("-" * 60)
    
    for k in kVals:
        if k in P and len(P[k]) > 0:
            avg_p = math.fsum(P[k]) / len(P[k])
            avg_r = math.fsum(R[k]) / len(R[k])
            avg_f1 = math.fsum(F1[k]) / len(F1[k])
            print(f"{k:<10} {avg_p:.4f}         {avg_r:.4f}         {avg_f1:.4f}")
        else:
            print(f"{k:<10} 0.0000         0.0000         0.0000")
    
    print("\n" + "=" * 60)
    print("Detailed results saved to: evaluation_details.txt")
    print("=" * 60)
    
    return {
        'MAP': math.fsum(AP) / len(AP) if AP else 0,
        'R-Precision': math.fsum(RP) / len(RP) if RP else 0,
        'nDCG': math.fsum(NDCG) / len(NDCG) if NDCG else 0
    }

def main():
    print("=" * 50)
    print("TREC Evaluation Script")
    print("=" * 50)
    
    # Parse command line arguments
    if len(sys.argv) == 3:
        qrel_file = sys.argv[1]
        rank_file = sys.argv[2]
        verbose = True
    elif len(sys.argv) == 4 and sys.argv[1] == '-q':
        qrel_file = sys.argv[2]
        rank_file = sys.argv[3]
        verbose = True
    else:
        # Default files
        print("\nNo command line arguments provided.")
        print("Usage: python trec_eval.py qrels.txt rankList.txt")
        print("Using default files: qrels.txt and rankList.txt\n")
        qrel_file = "qrels.txt"
        rank_file = "rankList.txt"
        verbose = True
    
    # Load data and calculate metrics
    print(f"Loading relevance judgements from: {qrel_file}")
    getRelevanceJudgements(qrel_file)
    
    print(f"Loading ranked results from: {rank_file}")
    queryResults = retrieveQueryResults(rank_file)
    print(f"Found {len(queryResults)} queries with results")
    
    # Calculate metrics
    results = calculateMetrics(queryResults, verbose)
    
    # Write summary to file
    with open("evaluation_summary.txt", 'w') as f:
        f.write("TREC Evaluation Summary\n")
        f.write("=" * 50 + "\n")
        f.write(f"MAP: {results['MAP']:.4f}\n")
        f.write(f"R-Precision: {results['R-Precision']:.4f}\n")
        f.write(f"nDCG: {results['nDCG']:.4f}\n")
    
    print("\nSummary saved to: evaluation_summary.txt")

if __name__ == "__main__":
    main()