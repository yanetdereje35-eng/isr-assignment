from elasticsearch import Elasticsearch
from elasticsearch_dsl import Search
import time
import math
import random
import decimal

# Set precision for perplexity/entropy calculations
decimal.getcontext().prec = 10

class Page:
    def __init__(self, page_id):
        self.page_id = page_id
        self.auth = 1.0
        self.hub = 1.0
        self.inLinkPages = set()
        self.outLinkPages = set()

def simple_entropy(rank):
    if rank <= 0: return 0
    return rank * math.log(rank, 2)

def calculate_hits(graph_pages, iterations=50):
    for i in range(iterations):
        # 1. Update Authority Scores
        norm_auth = 0
        for p_id in graph_pages:
            p = graph_pages[p_id]
            p.auth = sum(graph_pages[q_id].hub for q_id in p.inLinkPages)
            norm_auth += p.auth ** 2
        
        # Normalize Auth
        norm_auth = math.sqrt(norm_auth) if norm_auth > 0 else 1
        for p in graph_pages.values():
            p.auth /= norm_auth

        # 2. Update Hub Scores
        norm_hub = 0
        for p_id in graph_pages:
            p = graph_pages[p_id]
            p.hub = sum(graph_pages[r_id].auth for r_id in p.outLinkPages)
            norm_hub += p.hub ** 2
        
        # Normalize Hub
        norm_hub = math.sqrt(norm_hub) if norm_hub > 0 else 1
        for p in graph_pages.values():
            p.hub /= norm_hub
            
    print(f"Completed {iterations} iterations of HITS.")

# --- Main Execution ---
es = Elasticsearch(["http://localhost:9200"])
start_time = time.time()

# 1. Get Root Set via Query
res = es.search(
    index='hw3_crawl',
    size=1000,
    body={"query": {"match": {"text": "United States battles won in WW2"}}}
)

root_set = set()
base_set = set()
graph_pages = {}

# 2. Build Base Set
print("Building Base Set...")
for hit in res['hits']['hits']:
    pid = hit['_id']
    root_set.add(pid)
    base_set.add(pid)
    # Add pages the root set points to
    outlinks_raw = hit['_source'].get("outlinks", "").strip().split('\n')
    for ol in outlinks_raw:
        if ol.strip():
            base_set.add(ol.strip())

# 3. Initialize Page Objects
# Optimization: Fetch all needed docs in one go if possible, 
# but for HITS we focus on the base_set links
for pid in base_set:
    graph_pages[pid] = Page(pid)

# 4. Populate In-links and Out-links from linkgraph.txt
# This assumes linkgraph.txt contains: TargetURL SourceID1 SourceID2...
print("Loading Link Graph...")
try:
    with open("linkgraph.txt", 'r') as f:
        for line in f:
            parts = line.strip().split()
            if not parts: continue
            target = parts[0]
            sources = parts[1:]
            
            if target in graph_pages:
                for s_id in sources:
                    if s_id in graph_pages:
                        graph_pages[target].inLinkPages.add(s_id)
                        graph_pages[s_id].outLinkPages.add(target)
except FileNotFoundError:
    print("Warning: linkgraph.txt not found. Graph will be empty.")

# 5. Run Algorithm
calculate_hits(graph_pages, iterations=50)

# 6. Output Results
def save_results(filename, attribute, limit=500):
    sorted_pages = sorted(graph_pages.values(), key=lambda x: getattr(x, attribute), reverse=True)
    with open(filename, 'w') as f:
        for p in sorted_pages[:limit]:
            link_count = len(p.inLinkPages) if attribute == 'auth' else len(p.outLinkPages)
            f.write(f"{p.page_id} {getattr(p, attribute):.10f} {link_count}\n")

save_results("hub.txt", "hub")
save_results("authority.txt", "auth")

# 7. Time calculation
elapsed = time.time() - start_time
print(f"Total Time: {time.strftime('%H:%M:%S', time.gmtime(elapsed))}")