import math

# --- 1. THE DATA ---
# We use a string so the code doesn't look for a file that isn't there.
# Format: Target_URL Source_URL_1 Source_URL_2 ...
raw_graph_data = """
http://google.com http://wikipedia.org http://northeastern.edu
http://wikipedia.org http://google.com
http://northeastern.edu http://google.com
http://sink-node.com http://wikipedia.org
"""

# --- 2. THE PAGE CLASS ---
class Page:
    def __init__(self, url):
        self.url = url
        self.rank = 0.0
        self.in_links = set()
        self.out_link_count = 0

# --- 3. THE LOGIC ---
graph = {}

def build_graph(data):
    # Process each line
    for line in data.strip().split('\n'):
        parts = line.split()
        if not parts:
            continue
            
        target_url = parts[0]
        sources = parts[1:]
        
        # Ensure target exists
        if target_url not in graph:
            graph[target_url] = Page(target_url)
        
        # Add sources to the target's in-links
        graph[target_url].in_links.update(sources)
        
        # Increment out-link counts for all sources
        for src in sources:
            if src not in graph:
                graph[src] = Page(src)
            graph[src].out_link_count += 1

    # Initialize PageRank to 1/N
    n = len(graph)
    if n > 0:
        for p in graph.values():
            p.rank = 1.0 / n

# --- 4. EXECUTION ---
print("--- Initializing PageRank Graph ---")
build_graph(raw_graph_data)

# Identify Sinks and Sources
sinks = [url for url, p in graph.items() if p.out_link_count == 0]
sources = [url for url, p in graph.items() if len(p.in_links) == 0]

print(f"Total Nodes: {len(graph)}")
print(f"Sink Nodes (Dead Ends): {sinks}")
print(f"Source Nodes (No in-links): {sources}")

# Display Initial Ranks
print("\n--- Initial Ranks ---")
for url, p in graph.items():
    print(f"{url}: {p.rank:.4f}")