"""
 Written by Vinod Vishwanath
 Modified for bug fixes and VS Code compatibility
"""
from urllib.parse import urlparse

class Canonicalizer:

    @staticmethod
    def get_domain(url, include_scheme=True):
        parse = urlparse(url)
        # Default to http if no scheme is provided
        scheme = parse.scheme.lower() if parse.scheme else 'http'
        domain = parse.netloc.lower()
        
        # Clean the domain (remove default ports)
        clean_domain = Canonicalizer.clean_domain(domain, scheme)

        if include_scheme:
            return f"{scheme}://{clean_domain}"
        else:
            return clean_domain

    @staticmethod
    def is_relative_url(url):
        parse = urlparse(url)
        return parse.netloc == ''

    @staticmethod
    def canonicalize(url, domain=None):
        if domain is not None:
            # Ensure we don't double up on slashes
            url = domain.strip('/') + '/' + url.lstrip('/')

        parse = urlparse(url)
        scheme = parse.scheme.lower() if parse.scheme else 'http'
        
        output = scheme + '://'
        output += Canonicalizer.clean_domain(parse.netloc.lower(), scheme)
        
        if len(parse.path) > 0:
            output += Canonicalizer.clean_path(parse.path)

        return output

    @staticmethod
    def clean_domain(domain, scheme):
        if scheme == 'http':
            return rchop(domain, ':80')
        elif scheme == 'https':
            return rchop(domain, ':443')
        return domain

    @staticmethod
    def clean_path(path):
        # Remove redundant slashes and standardize
        comps = [c for c in path.split('/') if c]
        if not comps:
            return '/'
        return '/' + '/'.join(comps)

def rchop(string, ending):
    if string.endswith(ending):
        return string[:-len(ending)]
    return string

# --- Test Execution ---
if __name__ == "__main__":
    test_url = "https://www.en.wikipedia.org/wiki/World_War_II"
    
    print("Testing get_domain:")
    print(Canonicalizer.get_domain(test_url)) 
    
    print("\nTesting canonicalize:")
    print(Canonicalizer.canonicalize(test_url))