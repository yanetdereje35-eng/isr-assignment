from elasticsearch import Elasticsearch
from elasticsearch_dsl import Search
import time
import Canonicalizer

# Initialize ES client
es = Elasticsearch(["http://localhost:9200"])
canon = Canonicalizer.Canonicalizer

start_time = time.time()
linkgraphTemp = {}
linkGraph = {}
sinkNodes = set()

print("Scanning Elasticsearch index...")

# 1. Optimized Scan: Pull IDs and Outlinks together
s = Search(using=es, index="hw3_crawl")
s = s.source(['outlinks']) # Only fetch the outlinks field to save bandwidth

docID = set()

for hit in s.scan():
    curr_id = hit.meta.id.strip()
    docID.add(curr_id)
    
    # Get outlinks from the source
    outlinks_raw = hit.to_dict().get("outlinks", "")
    if outlinks_raw:
        # Clean and split the outlinks
        outlinks = set(link.strip() for link in outlinks_raw.strip().split('\n') if link.strip())
        
        for ol in outlinks:
            # You should use your canon.canonicalize(ol) here if needed
            if ol in linkgraphTemp:
                linkgraphTemp[ol].add(curr_id)
            else:
                linkgraphTemp[ol] = {curr_id}
    else:
        # If no outlinks exist, it's a potential sink node
        sinkNodes.add(curr_id)

# 2. Filter the graph
# Only keep links where the target was actually crawled (exists in docID)
for ol, inlinks in linkgraphTemp.items():
    if ol in docID:
        linkGraph[ol] = inlinks
    elif ol == '':
        sinkNodes.update(inlinks)

print(f"Detected {len(sinkNodes)} sink nodes.")

# 3. Write to File
with open("linkgraph.txt", "w", encoding="utf-8") as outputFile:
    for target_url, inlink_set in linkGraph.items():
        line = target_url + " " + " ".join(inlink_set)
        outputFile.write(line + '\n')

# 4. Final Timing
elapsed = time.time() - start_time
hours, rem = divmod(elapsed, 3600)
minutes, seconds = divmod(rem, 60)
print(f"Total Time: {int(hours)}:{int(minutes)}:{int(seconds)}")