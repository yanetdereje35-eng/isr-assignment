import math
import time

# --- 1. INLINED CANONICALIZER ---
# We put this here to avoid the "Module not available" error for external files
class Canonicalizer:
    @staticmethod
    def canonicalize(url):
        return url.strip().lower().rstrip('/')

# --- 2. THE PAGE CLASS ---
class Page:
    def __init__(self, page_id):
        self.page_id = page_id
        self.auth = 1.0
        self.hub = 1.0
        self.inLinkPages = set()
        self.outLinkPages = set()

# --- 3. THE DATA (MOCK FOR TESTING) ---
# Replace this string with the content of your graph.txt or linkgraph.txt
# Format: TargetURL SourceID1 SourceID2 ...
raw_link_data = """
https://en.wikipedia.org/wiki/ww2 https://history.com/battles https://archives.gov
https://history.com/battles https://en.wikipedia.org/wiki/ww2
https://archives.gov https://en.wikipedia.org/wiki/ww2
"""

# --- 4. GRAPH INITIALIZATION ---
graph_pages = {}

def initialize_graph(data):
    for line in data.strip().split('\n'):
        parts = line.split()
        if not parts: continue
        
        target = Canonicalizer.canonicalize(parts[0])
        sources = [Canonicalizer.canonicalize(s) for s in parts[1:]]
        
        if target not in graph_pages:
            graph_pages[target] = Page(target)
        
        for src_id in sources:
            if src_id not in graph_pages:
                graph_pages[src_id] = Page(src_id)
            
            # Map the relationship: Target gets an In-link, Source gets an Out-link
            graph_pages[target].inLinkPages.add(src_id)
            graph_pages[src_id].outLinkPages.add(target)

# --- 5. HITS ALGORITHM ---
def calculate_hits(iterations=20):
    for _ in range(iterations):
        # Update Authority
        norm_auth = 0
        for p in graph_pages.values():
            p.auth = sum(graph_pages[sid].hub for sid in p.inLinkPages)
            norm_auth += p.auth ** 2
        
        norm_auth = math.sqrt(norm_auth) if norm_auth > 0 else 1
        for p in graph_pages.values(): p.auth /= norm_auth

        # Update Hub
        norm_hub = 0
        for p in graph_pages.values():
            p.hub = sum(graph_pages[did].auth for did in p.outLinkPages)
            norm_hub += p.hub ** 2
            
        norm_hub = math.sqrt(norm_hub) if norm_hub > 0 else 1
        for p in graph_pages.values(): p.hub /= norm_hub

# --- EXECUTION ---
print("Initializing Graph...")
initialize_graph(raw_link_data)

print(f"Total Unique Pages: {len(graph_pages)}")
calculate_hits()

print("\n--- Top Authorities ---")
sorted_auth = sorted(graph_pages.values(), key=lambda x: x.auth, reverse=True)
for p in sorted_auth[:3]:
    print(f"{p.page_id}: {p.auth:.4f}")

print("\n--- Top Hubs ---")
sorted_hubs = sorted(graph_pages.values(), key=lambda x: x.hub, reverse=True)
for p in sorted_hubs[:3]:
    print(f"{p.page_id}: {p.hub:.4f}")