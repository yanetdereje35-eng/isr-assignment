import math

# --- 1. SIMULATED DATA (No files needed) ---
# Format: Target Source1 Source2 ...
graph_data = """
page_A page_B page_C
page_B page_A
page_C page_A
"""

class Page:
    def __init__(self, id):
        self.id = id
        self.auth = 1.0
        self.hub = 1.0
        self.in_links = set()
        self.out_links = set()

# --- 2. INITIALIZE GRAPH ---
pages = {}
for line in graph_data.strip().split('\n'):
    parts = line.split()
    target, sources = parts[0], parts[1:]
    if target not in pages: pages[target] = Page(target)
    pages[target].in_links.update(sources)
    for s in sources:
        if s not in pages: pages[s] = Page(s)
        pages[s].out_links.add(target)

# --- 3. RUN HITS ALGORITHM ---
for i in range(50):
    # Update Authorities
    norm_auth = 0
    for p in pages.values():
        p.auth = sum(pages[src].hub for src in p.in_links)
        norm_auth += p.auth ** 2
    
    # Normalize Auth (L2 Norm)
    norm_auth = math.sqrt(norm_auth) if norm_auth > 0 else 1
    for p in pages.values(): p.auth /= norm_auth

    # Update Hubs
    norm_hub = 0
    for p in pages.values():
        p.hub = sum(pages[dest].auth for dest in p.out_links)
        norm_hub += p.hub ** 2
    
    # Normalize Hub (L2 Norm)
    norm_hub = math.sqrt(norm_hub) if norm_hub > 0 else 1
    for p in pages.values(): p.hub /= norm_hub

# --- 4. THE EVALUATOR (Logic from your code) ---
def evaluate_scores(page_dict):
    total_hub = 0.0
    total_auth = 0.0
    total_hub_sq = 0.0
    
    for p in page_dict.values():
        total_hub += p.hub
        total_auth += p.auth
        total_hub_sq += (p.hub ** 2)
        
    return total_hub, total_auth, total_hub_sq

h_score, a_score, h_sq_sum = evaluate_scores(pages)

print("--- HITS Evaluation Results ---")
print(f"Total Hub Score (Sum): {h_score:.10f}")
print(f"Total Authority Score (Sum): {a_score:.10f}")
print(f"Sum of Squares (Should be 1.0): {h_sq_sum:.10f}")