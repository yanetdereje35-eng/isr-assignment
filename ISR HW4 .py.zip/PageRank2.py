import math
import decimal

# Set precision for perplexity calculations
decimal.getcontext().prec = 10
graphPages = {}
d = 0.85  # Damping factor

class Page:
    def __init__(self, page, rank, inLinkPages, noOfOutLinks):
        self.page = page
        self.rank = rank
        self.inLinkPages = inLinkPages
        self.noOfOutLinks = noOfOutLinks

def perplexity(ent):
    return pow(2, decimal.Decimal(ent))

def calculate_entropy(rank):
    if rank <= 0:
        return 0
    return rank * math.log(rank, 2)

def initialize_graph(data_string):
    """Parses raw string data to build the graph."""
    for line in data_string.strip().split('\n'):
        parts = line.strip().split()
        if not parts:
            continue
        
        target = parts[0]
        sources = parts[1:]
        
        if target not in graphPages:
            graphPages[target] = Page(target, 0, set(), 0)
        
        # Add the incoming links to the target
        graphPages[target].inLinkPages.update(sources)
        
        # Ensure sources exist in graph and increment their out-link counts
        for src in sources:
            if src not in graphPages:
                graphPages[src] = Page(src, 0, set(), 0)
            graphPages[src].noOfOutLinks += 1

    # Initialize all pages with uniform rank 1/N
    N = len(graphPages)
    if N > 0:
        for p in graphPages.values():
            p.rank = 1.0 / N

def calculate_pagerank(sink_nodes):
    N = len(graphPages)
    if N == 0: return 0
        
    # Calculate rank leaked by sink nodes
    sink_pr_sum = sum(graphPages[node].rank for node in sink_nodes)
    
    new_ranks = {}
    for pid, p_obj in graphPages.items():
        # Teleportation + Sink redistribution
        rank = (1.0 - d) / N
        rank += d * (sink_pr_sum / N)
        
        # Contribution from neighbors
        for incoming in p_obj.inLinkPages:
            source = graphPages[incoming]
            if source.noOfOutLinks > 0:
                rank += d * (source.rank / source.noOfOutLinks)
        
        new_ranks[pid] = rank

    # Apply new ranks and calculate entropy for perplexity
    total_entropy = 0
    for pid in graphPages:
        graphPages[pid].rank = new_ranks[pid]
        total_entropy += calculate_entropy(new_ranks[pid])
    
    return perplexity(-total_entropy)

# --- CONFIGURATION & DATA ---

# If you are in VS Code with the real file, set USE_FILE = True
# If you are on an online compiler, set USE_FILE = False
USE_FILE = False 
filename = "wt2g_inlinks.txt"

# Sample data representing: TargetPage SourcePage1 SourcePage2 ...
sample_data = """
pageA pageB pageC
pageB pageA
pageC pageA pageB
pageD pageC
pageE 
"""

# --- MAIN EXECUTION ---

try:
    if USE_FILE:
        print(f"Reading from {filename}...")
        with open(filename, 'r') as f:
            initialize_graph(f.read())
    else:
        print("Running with sample data (Online Mode)...")
        initialize_graph(sample_data)

    sink_nodes = [k for k, v in graphPages.items() if v.noOfOutLinks == 0]
    
    print(f"Total Nodes: {len(graphPages)}")
    print(f"Sink Nodes: {len(sink_nodes)}")
    
    prev_perp = 0
    convergence_count = 0
    iteration = 0
    
    while convergence_count < 4:
        iteration += 1
        curr_perp = calculate_pagerank(sink_nodes)
        print(f"Iteration {iteration} | Perplexity: {curr_perp:.4f}")
        
        if abs(curr_perp - prev_perp) < 1:
            convergence_count += 1
        else:
            convergence_count = 0
        prev_perp = curr_perp

    # Output Top Results
    print("\n--- Top PageRanks ---")
    sorted_pages = sorted(graphPages.values(), key=lambda x: x.rank, reverse=True)
    for p in sorted_pages[:10]:
        print(f"{p.page}: {p.rank:.6f} (In-links: {len(p.inLinkPages)})")

except Exception as e:
    print(f"Error: {e}")