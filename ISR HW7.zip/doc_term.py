"""
Standalone (no Elasticsearch) baseline:
sklearn CountVectorizer + Logistic Regression on the parsed email files.

Usage:
    python doc_term.py --files-dir Files --stoplist stoplist.txt
"""
import argparse
import os
import pickle
import re

import nltk
import numpy as np
from bs4 import BeautifulSoup
from sklearn import model_selection, preprocessing
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

nltk.download('words', quiet=True)
ENGLISH_WORDS = set(w.lower() for w in nltk.corpus.words.words())
TOKEN_RE = re.compile(r"[A-Za-z]{2,}")


def english_only(text: str) -> str:
    return ' '.join(w for w in TOKEN_RE.findall(text)
                    if w.lower() in ENGLISH_WORDS)


def load_corpus(files_dir: str):
    texts, labels, doc_ids = [], [], []
    for fname in os.listdir(files_dir):
        if not fname.endswith('.txt'):
            continue
        with open(os.path.join(files_dir, fname), 'r',
                  encoding='utf-8', errors='replace') as f:
            soup = BeautifulSoup(f'<root>{f.read()}</root>', 'html.parser')
        if not (soup.label and soup.emailid):
            continue
        text = ' '.join(t.get_text(' ', strip=True) for t in soup.find_all('text'))
        texts.append(english_only(text))
        labels.append(soup.label.get_text(strip=True))
        doc_ids.append(soup.emailid.get_text(strip=True))
    return texts, labels, doc_ids


def load_stopwords(path: str | None) -> list[str]:
    if path and os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    nltk.download('stopwords', quiet=True)
    return nltk.corpus.stopwords.words('english')


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--files-dir', default='Files')
    p.add_argument('--stoplist', default='stoplist.txt')
    p.add_argument('--cache', default='corpus_cache.pkl')
    args = p.parse_args()

    if os.path.exists(args.cache):
        print(f'Loading cached corpus from {args.cache}')
        with open(args.cache, 'rb') as f:
            texts, labels, doc_ids = pickle.load(f)
    else:
        print('Reading and cleaning corpus (slow, one-time)...')
        texts, labels, doc_ids = load_corpus(args.files_dir)
        with open(args.cache, 'wb') as f:
            pickle.dump((texts, labels, doc_ids), f)

    stopwords = load_stopwords(args.stoplist)

    vec = CountVectorizer(stop_words=stopwords)
    X = vec.fit_transform(texts)
    y = preprocessing.LabelEncoder().fit_transform(np.array(labels))

    kfold = model_selection.KFold(n_splits=5, shuffle=True, random_state=42)
    train_idx, test_idx = next(kfold.split(X, y))

    clf = LogisticRegression(max_iter=1000, n_jobs=-1)
    clf.fit(X[train_idx], y[train_idx])
    preds = clf.predict(X[test_idx])

    print(f'Accuracy: {accuracy_score(y[test_idx], preds) * 100:.2f}%')
    print(classification_report(y[test_idx], preds))


if __name__ == '__main__':
    main()
