from __future__ import division
import os
import re
import time
import dill
from bs4 import BeautifulSoup
from stemming.porter2 import stem
from collections import OrderedDict

class TermVector:
    def __init__(self, tf, pos):
        self.tf = tf
        self.pos = pos

def unpickler(file):
    with open(file, 'rb') as f:
        return dill.load(f)

def parseCatalog(file):
    catalog = {}
    if not os.path.exists(file):
        return catalog
    with open(file, 'r') as catalogFile:
        for line in catalogFile.readlines():
            content = line.strip().split(',')
            if len(content) >= 2:
                # catalog[termID] = [offset, length]
                catalog[content[0]] = content[1:]
    return catalog

def queryMaker():
    """Parses cran.qry.xml for IDs and text content."""
    query_file = 'cran.qry.xml'
    queries = [] 
    
    if not os.path.exists(query_file):
        print(f"Error: {query_file} not found!")
        return queries

    with open(query_file, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f.read(), 'xml')
        query_nodes = soup.find_all(['top', 'query', 'doc', 'DOC']) 
        
        for i, node in enumerate(query_nodes, start=1):
            num_tag = node.find(['num', 'docno', 'DOCNO'])
            q_id = num_tag.text.strip() if num_tag else str(i)
            
            text_tag = node.find(['title', 'text', 'TEXT'])
            q_text = text_tag.text.strip() if text_tag else ""
            
            queries.append((q_id, q_text))
            
    return queries

def queryProcessor(query_text):
    """Tokenizes, removes stopwords, and stems query terms."""
    stoplist_path = 'stoplist.txt'
    if os.path.exists(stoplist_path):
        with open(stoplist_path, "r") as sfile:
            stopWords = set(line.strip().lower() for line in sfile)
    else:
        stopWords = set()

    # Regex matches words/numbers with internal periods (98.6)
    tokens = re.findall(r'\w+(?:\.\w+)*', query_text.lower())
    
    # Filter and Stem
    stemmed_keywords = [stem(t) for t in tokens if t not in stopWords]
    return stemmed_keywords

def getInfo(term_text, catalog, termMap, docMap):
    """Retrieves postings for a stemmed term from the stemmed index."""
    invList = OrderedDict()
    keyInfo = OrderedDict()

    termID = termMap.get(term_text)
    if termID is None:
        return None, None
    

    cat_entry = catalog.get(str(termID))
    if not cat_entry:
        return None, None
        
    offset = int(cat_entry[0])
 
    try:
        with open("Stemmed/invertedFile0.txt", 'r') as indexFile:
            indexFile.seek(offset)
            line = indexFile.readline()
        
        header, data = line.split(':')
        header_parts = header.split(',')
        df = header_parts[1]
        ttf = header_parts[2]
        keyInfo[term_text] = [df, ttf]
        
        docDict = OrderedDict()
        remStr = data.strip().split(';')
        for item in remStr:
            if not item: continue
            parts = item.split(',')
            docID_int = int(parts[0])
            doc_no_str = docMap.get(docID_int)
            tf = int(parts[1])
            pos = [int(e) for e in parts[2:]]
            docDict[doc_no_str] = TermVector(tf, pos)
            
        invList[term_text] = docDict
        return invList, keyInfo
    except Exception:
        return None, None

def getParameters(query_text, qID):
    """Processes queries and pickles the resulting vectors/stats."""
    keywords = queryProcessor(query_text)
    termVector = OrderedDict()
    termStats = OrderedDict()
    
    for stemmed_word in keywords:
        invList, keyInfo = getInfo(stemmed_word, catalog, termMap, docMap)
        if invList:
            termVector.update(invList)
            termStats.update(keyInfo)
            
    pickle_path = 'Stemmed/Pickles'
    os.makedirs(pickle_path, exist_ok=True)
    
    with open(f'{pickle_path}/termStats_{qID}.p', 'wb') as f:
        dill.dump(termStats, f)
    with open(f'{pickle_path}/termVector_{qID}.p', 'wb') as f:
        dill.dump(termVector, f)


if __name__ == "__main__":
    start_time = time.time()

    print("Loading Stemmed Index data...")
    docInfo = unpickler('Stemmed/Pickles/docInfo.p')
    catalog = parseCatalog('Stemmed/catalogFile.txt')
    termMap = unpickler('Stemmed/Pickles/termMap.p')
    docMap = unpickler('Stemmed/Pickles/docMap.p')

    queries = queryMaker()
    print(f"Processing {len(queries)} stemmed queries...")

    for qID, qText in queries:
        getParameters(qText, qID)
        print(f"Generated TermVector for Query: {qID}")

    total_time = time.time() - start_time
    print(f"Finished in: {time.strftime('%H:%M:%S', time.gmtime(total_time))}")