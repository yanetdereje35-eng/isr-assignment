from __future__ import division
import math
from operator import itemgetter
from collections import defaultdict
import string
import dill


def restructureTV(termVector):
    dictDocID = defaultdict(lambda: defaultdict(list))

    for key in termVector:
        for docid in termVector[key]:
            dictDocID[docid][key] = [
                termVector[key][docid].getTF(),
                termVector[key][docid].getPos()
            ]

    return dictDocID


def Total_okapiTF(qNo, termVector, termStats, docInfo):
    docScore = []
    dictDocID = restructureTV(termVector)

    for docid in dictDocID:
        score = 0.0
        docLen = int(docInfo.get(docid))

        for key in dictDocID[docid]:
            tfwd = dictDocID[docid][key][0]
            score += tfwd / (tfwd + 0.5 + 1.5 * (docLen / avgDocLen))

        docScore.append([docid, score])

    docScore.sort(key=itemgetter(1), reverse=True)

    with open('Stemmed/OkapiTF_Results_File.txt', 'a+') as f:
        rank = 1
        for ds in docScore:
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")
            if rank == 1000:
                break
            rank += 1


def Okapi_BM25(qNo, termVector, termStats, docInfo):
    k1, k2, b = 1.2, 1.2, 0.75
    docScore = []
    dictDocID = restructureTV(termVector)

    for docid in dictDocID:
        bm25 = 0.0
        docLen = int(docInfo.get(docid))

        for key in dictDocID[docid]:
            tfwd = dictDocID[docid][key][0]
            df = int(termStats[key][0])

            idf = math.log10((D + 0.5) / (df + 0.5))

            tf_part = (tfwd + k1 * tfwd) / (tfwd + k1 * ((1 - b) + b * (docLen / avgDocLen)))
            q_part = (tfwd + k2 * tfwd) / (tfwd + k2)

            bm25 += idf * tf_part * q_part

        docScore.append([docid, bm25])

    docScore.sort(key=itemgetter(1), reverse=True)

    with open('Stemmed/OkapiBM25_Results_File.txt', 'a+') as f:
        rank = 1
        for ds in docScore:
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")
            if rank == 1000:
                break
            rank += 1


def UnigramLM_Laplace(qNo, termVector, docInfo, V):
    dictDocID = restructureTV(termVector)
    docScoreDict = {}

    for docid in dictDocID:
        docLen = int(docInfo.get(docid))
        score = 0.0

        for word in dictDocID[docid]:
            tfwd = dictDocID[docid][word][0]
            p = (tfwd + 1) / (docLen + V)
            score += math.log(p)

        docScoreDict[docid] = score

    ranked = sorted(docScoreDict.items(), key=itemgetter(1), reverse=True)

    with open('Stemmed/UnigramLMLaplace_Results_File.txt', 'a+') as f:
        rank = 1
        for docid, score in ranked:
            f.write(f"{qNo} Q0 {docid} {rank} {score} Exp\n")
            if rank == 1000:
                break
            rank += 1


def rangeOfWindow(pos):
    minROW = float("inf")
    keyPos = {k: pos[k][0] for k in pos}

    while len(keyPos) == len(pos):
        row = max(keyPos.values()) - min(keyPos.values())

        min_key = min(keyPos, key=keyPos.get)
        min_index = pos[min_key].index(keyPos[min_key])

        if min_index < len(pos[min_key]) - 1:
            keyPos[min_key] = pos[min_key][min_index + 1]
        else:
            keyPos.pop(min_key)

        minROW = min(minROW, row)

    return minROW


def proximity(qNo, termVector, termStats, docInfo):
    docScore = []
    dictDocID = restructureTV(termVector)
    c = 1500

    for docid in dictDocID:
        pos = {}
        i = 0
        docLen = int(docInfo.get(docid))

        for key in dictDocID[docid]:
            pos[key] = dictDocID[docid][key][1]
            i += 1

        row = rangeOfWindow(pos)
        score = (c - row) * i / (docLen + V)

        docScore.append([docid, score])

    docScore.sort(key=itemgetter(1), reverse=True)

    with open('Stemmed/Results/Proximity_Results_File.txt', 'a+') as f:
        rank = 1
        for ds in docScore:
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")
            if rank == 1000:
                break
            rank += 1


def queryNums():
    with open('QueryUpdated.txt', 'r') as f:
        return [line.split()[0].translate(None, string.punctuation) for line in f]


def unpickler(file):
    with open(file, 'rb') as f:
        return dill.load(f)


def parseCatalog(file):
    catalog = {}
    with open(file, 'r') as f:
        for line in f:
            content = line.strip().split(',')
            catalog[content[0]] = content[1:]
    return catalog


termMap = unpickler('Stemmed/Pickles/termMap.p')
catalog = parseCatalog('Stemmed/catalogFile.txt')
docInfo = unpickler('Stemmed/Pickles/docInfo.p')

avgDocLen = sum(docInfo.values()) / len(docInfo)
V = len(catalog)

D = 84678

qNums = queryNums()

i = 0
for qNo in qNums:
    i += 1
    termStats = unpickler(f'Stemmed/Pickles/termStats_Proximity{i}.p')
    termVector = unpickler(f'Stemmed/Pickles/termVector_Proximity{i}.p')

    print(f"Running Query {i} out of 25")

    proximity(qNo, termVector, termStats, docInfo)

print("Done!")