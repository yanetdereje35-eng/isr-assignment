from __future__ import division
import math
from operator import itemgetter
from collections import defaultdict
from bs4 import BeautifulSoup
import string
import dill
import os
import sys
# This 'tricks' the unpickler into finding the class where it expects it
sys.modules['Stemmed_Stopwords_Removed_Index'] = sys.modules[__name__]
# -----------------------------
# BASE PATH & HELPER CLASSES
# -----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

class TermVector:
    def __init__(self, tf, pos):
        self.tf = tf
        self.pos = pos
    def getTF(self): return self.tf
    def getPos(self): return self.pos
    
def restructureTV(termVector):
    """Converts term-centric pickles to document-centric dictionaries."""
    dictDocID = defaultdict(lambda: defaultdict(list))
    for key in termVector:
        for docid in termVector[key]:
            # Added a safety check in case the object isn't a TermVector class
            obj = termVector[key][docid]
            tf = obj.getTF() if hasattr(obj, 'getTF') else obj[0]
            pos = obj.getPos() if hasattr(obj, 'getPos') else obj[1]
            dictDocID[docid][key] = [tf, pos]
    return dictDocID

def unpickler(path):
    if not os.path.exists(path): return None
    with open(path, 'rb') as f:
        return dill.load(f)

def parseCatalog(file):
    catalog = {}
    if not os.path.exists(file): return catalog
    with open(file, 'r') as f:
        for line in f:
            content = line.strip().split(',')
            if len(content) >= 2:
                catalog[content[0]] = content[1:]
    return catalog

def queryNums():
    qry_path = os.path.join(BASE_DIR, "cran.qry.xml")
    if not os.path.exists(qry_path):
        print(f"Warning: {qry_path} not found. Using default range 1-225.")
        return [str(x) for x in range(1, 226)]
    with open(qry_path, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f, "xml")
    queries = soup.find_all("top")
    qNums = []
    for q in queries:
        num_tag = q.find("num")
        if num_tag:
            qNo = num_tag.get_text().strip().split()[-1]
            qNums.append(qNo)
    return qNums

# -----------------------------
# LOAD GLOBAL DATA
# -----------------------------
# Ensure paths are normalized for the OS
UNSTEMMED_DIR = os.path.join(BASE_DIR, 'Unstemmed')
PICKle_DIR = os.path.join(UNSTEMMED_DIR, 'Pickles')
RESULTS_DIR = os.path.join(UNSTEMMED_DIR, 'Results')

os.makedirs(RESULTS_DIR, exist_ok=True)

catalog = parseCatalog(os.path.join(UNSTEMMED_DIR, 'catalogFile1.txt'))
docInfo = unpickler(os.path.join(PICKle_DIR, 'docInfo.p'))

if not docInfo:
    print("Critical Error: docInfo.p could not be loaded. Check file paths.")
    exit()

avgDocLen = sum(docInfo.values()) / len(docInfo)
V = len(catalog) if len(catalog) > 0 else 100000 # Fallback V
D = len(docInfo)

# -----------------------------
# MODELS
# -----------------------------

def Total_okapiTF(qNo, termVector, docInfo):
    docScore = []
    dictDocID = restructureTV(termVector)
    for docid, terms in dictDocID.items():
        score = 0
        docLen = int(docInfo.get(docid, avgDocLen))
        for key in terms:
            tfwd = terms[key][0]
            score += tfwd / (tfwd + 0.5 + (1.5 * (docLen / avgDocLen)))
        docScore.append([docid, score])
    docScore.sort(key=itemgetter(1), reverse=True)
    with open(os.path.join(RESULTS_DIR, 'OkapiTF_Results_File.txt'), 'a') as f:
        for rank, ds in enumerate(docScore[:1000], start=1):
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")

def Okapi_BM25(qNo, termVector, termStats, docInfo):
    k1, k2, b = 1.2, 1.2, 0.75
    docScore = []
    dictDocID = restructureTV(termVector)
    for docid, terms in dictDocID.items():
        score = 0
        docLen = int(docInfo.get(docid, avgDocLen))
        for key in terms:
            tfwd = terms[key][0]
            df = int(termStats[key][0]) if key in termStats else 1
            idf = math.log10((D + 0.5) / (df + 0.5))
            tf = (tfwd * (k1 + 1)) / (tfwd + k1 * ((1 - b) + b * (docLen / avgDocLen)))
            qtf = (tfwd * (k2 + 1)) / (tfwd + k2)
            score += idf * tf * qtf
        docScore.append([docid, score])
    docScore.sort(key=itemgetter(1), reverse=True)
    with open(os.path.join(RESULTS_DIR, 'OkapiBM25_Results_File.txt'), 'a') as f:
        for rank, ds in enumerate(docScore[:1000], start=1):
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")

def UnigramLM_Laplace(qNo, termVector, termStats, docInfo):
    dictDocID = restructureTV(termVector)
    docScoreDict = {}
    for docid in dictDocID:
        score = 0
        docLen = int(docInfo.get(docid, avgDocLen))
        for word in termStats:
            tfwd = dictDocID[docid][word][0] if word in dictDocID[docid] else 0
            prob = (tfwd + 1) / (docLen + V)
            score += math.log(prob)
        docScoreDict[docid] = score
    DocScore = sorted(docScoreDict.items(), key=itemgetter(1), reverse=True)
    with open(os.path.join(RESULTS_DIR, 'UnigramLMLaplace_Results_File.txt'), 'a') as f:
        for rank, ds in enumerate(DocScore[:1000], start=1):
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")

def UnigramLM_JelinekMercer(qNo, termVector, termStats, docInfo):
    dictDocID = restructureTV(termVector)
    l = 0.8
    docScoreDict = {}
    for docid in dictDocID:
        score = 0
        docLen = int(docInfo.get(docid, avgDocLen))
        if docLen == 0: continue
        for word in termStats:
            cTF = int(termStats[word][1]) if word in termStats else 1
            pML = cTF / V
            tfwd = dictDocID[docid][word][0] if word in dictDocID[docid] else 0
            prob = l * (tfwd / docLen) + (1 - l) * pML
            if prob > 0: score += math.log(prob)
        docScoreDict[docid] = score
    DocScore = sorted(docScoreDict.items(), key=itemgetter(1), reverse=True)
    with open(os.path.join(RESULTS_DIR, 'UnigramLMJM_Results_File.txt'), 'a') as f:
        for rank, ds in enumerate(DocScore[:1000], start=1):
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")

def proximity(qNo, termVector, docInfo):
    docScore = []
    dictDocID = restructureTV(termVector)
    c = 1500
    for docid, terms in dictDocID.items():
        pos = {key: data[1] for key, data in terms.items()}
        docLen = int(docInfo.get(docid, avgDocLen))
        if len(pos) < 1: continue 
        
        # Fixed logic: Row calculation for documents with 1 or more terms
        all_pos = [p for sublist in pos.values() for p in sublist]
        row = max(all_pos) - min(all_pos)
        
        # If row is larger than C, score becomes 0 or negative; guard it if needed
        score = (c - row) * len(pos) / (docLen + V)
        docScore.append([docid, score])
    docScore.sort(key=itemgetter(1), reverse=True)
    with open(os.path.join(RESULTS_DIR, 'Proximity_Results_File.txt'), 'a') as f:
        for rank, ds in enumerate(docScore[:1000], start=1):
            f.write(f"{qNo} Q0 {ds[0]} {rank} {ds[1]} Exp\n")

# -----------------------------
# MAIN
# -----------------------------
qNums = queryNums()

# Clear old results files to prevent appending to old data
for model_file in os.listdir(RESULTS_DIR):
    if model_file.endswith(".txt"):
        os.remove(os.path.join(RESULTS_DIR, model_file))

for i, qNo in enumerate(qNums, start=1):
    print(f"Running Query {qNo} (Loop index {i})")
    
    # Using normalized paths for pickles
    stats_path = os.path.join(PICKle_DIR, f'termStats_Proximity{i}.p')
    vector_path = os.path.join(PICKle_DIR, f'termVector_Proximity{i}.p')
    
    termStats = unpickler(stats_path)
    termVector = unpickler(vector_path)

    if termStats and termVector:
        Total_okapiTF(qNo, termVector, docInfo)
        Okapi_BM25(qNo, termVector, termStats, docInfo)
        UnigramLM_Laplace(qNo, termVector, termStats, docInfo)
        UnigramLM_JelinekMercer(qNo, termVector, termStats, docInfo)
        proximity(qNo, termVector, docInfo)
    else:
        print(f"Skipping Query {qNo}: Pickle files not found.")

print("DONE! All Retrieval Models Executed.")