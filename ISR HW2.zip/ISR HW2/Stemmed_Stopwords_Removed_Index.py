from stemming.porter2 import stem
from bs4 import BeautifulSoup
import os
import re
import dill
import time
from collections import defaultdict, OrderedDict

# -----------------------------
# PATH SETUP - FIXED FOR YOUR FOLDERS
# -----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 1. Path to your dataset and stoplist
DATA_FILE = os.path.join(BASE_DIR, "cran.all.1400.xml")
STOPLIST_FILE = os.path.join(BASE_DIR, "stoplist.txt")

# 2. Point to your EXISTING Stemmed folder
# This ensures we don't create "Files/Stemmed" if you just have "Stemmed"
OUTPUT_DIR = os.path.join(BASE_DIR, "Stemmed") 
PICKLE_DIR = os.path.join(OUTPUT_DIR, "Pickles")

# We only create them if for some reason they went missing, 
# otherwise, it uses the ones you already have.
os.makedirs(PICKLE_DIR, exist_ok=True)

# -----------------------------
# LOAD STOPWORDS
# -----------------------------
try:
    with open(STOPLIST_FILE, "r") as f:
        stopWords = set(word.strip().lower() for word in f.readlines())
except FileNotFoundError:
    print(f"Warning: {STOPLIST_FILE} not found.")
    stopWords = set()

# -----------------------------
# TOKENIZER (README COMPLIANT)
# -----------------------------
def tokenize(text):
    # Matches words/numbers and allows internal periods (e.g., 98.6)
    token_pattern = re.compile(r'\w+(?:\.\w+)*')
    matches = token_pattern.finditer(text.lower())
    
    stemmed_tokens = []
    for match in matches:
        t = match.group()
        if t not in stopWords:
            stemmed_tokens.append(stem(t))
    return stemmed_tokens

# -----------------------------
# LOAD CRANFIELD DATA
# -----------------------------
def load_documents():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f.read(), "xml")

    # Handles both lowercase <doc> and uppercase <DOC>
    docs = soup.find_all("doc") or soup.find_all("DOC")

    documents = {}
    for doc in docs:
        docno_tag = doc.find("docno") or doc.find("DOCNO")
        text_tag = doc.find("text") or doc.find("TEXT")
        title_tag = doc.find("title") or doc.find("TITLE")

        doc_id = docno_tag.text.strip() if docno_tag else str(len(documents)+1)
        
        content = ""
        if title_tag: content += title_tag.text + " "
        if text_tag: content += text_tag.text
        
        documents[doc_id] = content
    return documents

# -----------------------------
# BUILD INVERTED INDEX
# -----------------------------
def build_index(documents):
    termDict = defaultdict(lambda: defaultdict(list))
    docInfo = {}
    docMap = {}
    doc_id_counter = 1

    for docno, text in documents.items():
        tokens = tokenize(text)
        docInfo[docno] = len(tokens)
        docMap[doc_id_counter] = docno

        for pos, term in enumerate(tokens, start=1):
            termDict[term][doc_id_counter].append(pos)
        doc_id_counter += 1

    return termDict, docInfo, docMap

# -----------------------------
# WRITE INDEX FILE
# -----------------------------
def write_index(termDict, docMap, docInfo):
    inv_path = os.path.join(OUTPUT_DIR, "invertedFile0.txt")
    cat_path = os.path.join(OUTPUT_DIR, "catalogFile.txt")

    with open(inv_path, "w") as invFile, open(cat_path, "w") as catFile:
        term_id = 1
        for term in sorted(termDict.keys()):
            postings = termDict[term]
            offset = invFile.tell()

            df = len(postings)
            ttf = sum(len(pos_list) for pos_list in postings.values())

            # Start the line
            line = f"{term_id},{df},{ttf}:"
            
            # Sort by TF descending
            sorted_docs = sorted(postings.items(), key=lambda x: len(x[1]), reverse=True)

            for doc_id, pos_list in sorted_docs:
                tf = len(pos_list)
                positions = ",".join(map(str, pos_list))
                line += f"{doc_id},{tf},{positions};"

            line = line.rstrip(";") + "\n"
            invFile.write(line)
            catFile.write(f"{term_id},{offset},{len(line)}\n")
            term_id += 1

    # SAVE PICKLES INTO YOUR EXISTING PICKLE FOLDER
    pickles = {
        "docMap.p": docMap,
        "docInfo.p": docInfo,
        # We create a termMap here too based on the stemmed terms
        "termMap.p": {term: i+1 for i, term in enumerate(sorted(termDict.keys()))}
    }

    for filename, data in pickles.items():
        with open(os.path.join(PICKLE_DIR, filename), "wb") as f:
            dill.dump(data, f)

# -----------------------------
# MAIN
# -----------------------------
def main():
    start_time = time.time()
    print(f"Loading documents from {DATA_FILE}...")
    docs = load_documents()
    
    print(f"Building stemmed index for {len(docs)} documents...")
    termDict, docInfo, docMap = build_index(docs)

    print(f"Writing files to existing folder: {OUTPUT_DIR}")
    write_index(termDict, docMap, docInfo)

    print(f"DONE! Total time: {time.time() - start_time:.2f}s")

if __name__ == "__main__":
    main()