import time
from bs4 import BeautifulSoup
import os
import re
from collections import defaultdict, OrderedDict
import dill

# --- 1. SUPPORT CLASSES ---
class TermVector:
    def __init__(self, tf, pos):
        self.tf = tf
        self.pos = pos

    def getTF(self):
        return self.tf

    def getPos(self):
        return self.pos

class CatalogTerm:
    def __init__(self, term, offset, length):
        self.term = term
        self.offset = offset
        self.length = length

class Catalog:
    def __init__(self):
        self.terms = {}
        self.termMap = {}
        
    def addTerm(self, term, offset, length, fileName, termid):
        if term not in self.terms:
            self.terms[term] = {}
            self.termMap[term] = termid
        self.terms[term][fileName] = CatalogTerm(term, offset, length)

    def removeTerm(self, term):
        if term in self.terms:
            del self.terms[term]

# --- 2. GLOBAL VARIABLES ---
docNoSet = {}
docMap = {}
catalog = Catalog()

# --- 3. UTILITY FUNCTIONS ---
def pickler(path, ds):
    with open(path, 'wb') as f:
        dill.dump(ds, f)

def writeHashMap(hashMap, fileName):
    path = 'Unstemmed/Maps/%s' % fileName
    with open(path, 'w') as mapFile:
        for key, value in hashMap.items():
            mapFile.write(str(key) + ',' + str(value) + '\n')

def calcTTF(termdict, term):
    return sum(doc_vec.getTF() for doc_vec in termdict[term].values())

def calcDF(termdict, term):
    return len(termdict[term])

# --- 4. CORE INDEXING LOGIC ---
def tokenizer(text):
    posToken = []
    token_pattern = re.compile(r'\w+(?:\.\w+)*')
    matches = token_pattern.finditer(text.lower())
    for i, match in enumerate(matches, start=1):
        token = match.group()
        posToken.append([token, i])
    return posToken

def constructDict(tokens):
    termDict = defaultdict(lambda: defaultdict(TermVector))
    for token_text, pos, dID in tokens:
        if token_text in termDict and dID in termDict[token_text]:
            termDict[token_text][dID].tf += 1
            termDict[token_text][dID].pos.append(pos)
        else:
            termDict[token_text][dID] = TermVector(1, [pos])
    return termDict

def loadCatalog(termDict, fileName, invFileNo, catalogFile=None):
    fName = '%s%s.txt' % (fileName, invFileNo)
    with open(fName, "a+") as invFile:
        for term in termDict:
            offset = invFile.tell()
            ttf = calcTTF(termDict, term)
            df = calcDF(termDict, term)
            
            if term not in catalog.termMap:
                termid = len(catalog.termMap) + 1
                catalog.termMap[term] = termid
            else:
                termid = catalog.termMap[term]

            inputStr = [str(termid), ',', str(df), ',', str(ttf), ':']
            for docno in termDict[term]:
                if docno not in docNoSet:
                    docid = len(docMap) + 1
                    docNoSet[docno] = docid
                    docMap[docid] = docno
                else:
                    docid = docNoSet[docno]
                
                inputStr.append(str(docid))
                inputStr.append(',')
                inputStr.append(str(termDict[term][docno].getTF()))
                inputStr.append(',')
                inputStr.append(','.join(str(e) for e in termDict[term][docno].getPos()))
                inputStr.append(';')
            
            inputStr[-1] = '\n'
            writeStr = ''.join(inputStr)
            length = len(writeStr)
            catalog.addTerm(term, offset, length, fName, termid)
            
            # Write partial catalog
            tempCatPath = 'Unstemmed/catalogFile%d.txt' % invFileNo
            with open(tempCatPath, 'a+') as tempCat:
                tempCat.write("%s,%s,%s\n" % (termid, offset, length))
            
            invFile.write(writeStr)
    return invFileNo + 1

def indexer(tokens, invFile):
    if not tokens: return invFile
    termDict = constructDict(tokens)
    return loadCatalog(termDict, "Unstemmed/invertedFile", invFile)

# --- 5. DATASET LOADING ---
def getText(doc):
    content = []
    title = doc.find('title')
    if title: content.append(title.get_text())
    text_body = doc.find('text')
    if text_body: content.append(text_body.get_text())
    return " ".join(content)

def getTokens():
    # UPDATE THIS TO YOUR PATH
    cran_file_path = r"C:\Users\YANIT\OneDrive\Desktop\HW1\HW2 IR_PROJECT\cran.all.1400.xml"
    
    tokens = []
    docInfo = {}
    countDoc = 0
    invFile = 1

    os.makedirs('Unstemmed/Pickles/', exist_ok=True)
    os.makedirs('Unstemmed/Maps/', exist_ok=True)

    print("Reading Cranfield dataset...")
    with open(cran_file_path, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f.read(), 'xml')
        docs = soup.find_all('doc') 

        for doc in docs:
            countDoc += 1
            raw_text = getText(doc)
            doc_id_tag = doc.find('docno')
            docNo = doc_id_tag.get_text().strip() if doc_id_tag else str(countDoc)
            
            posTokens = tokenizer(raw_text)
            docInfo[docNo] = len(posTokens)
            for t in posTokens:
                t.append(docNo)
            
            tokens += posTokens
            if countDoc % 500 == 0:
                invFile = indexer(tokens, invFile)
                tokens = []

    if tokens:
        indexer(tokens, invFile)

    pickler('Unstemmed/Pickles/termMap.p', catalog.termMap)
    writeHashMap(catalog.termMap, 'termMap.txt')
    pickler('Unstemmed/Pickles/docMap.p', docMap)
    writeHashMap(docMap, 'docMap.txt')
    pickler('Unstemmed/Pickles/docInfo.p', docInfo)

# --- 6. MAIN EXECUTION ---
def main():
    start_time = time.time()
    getTokens()
    print("Indexing Complete!")
    duration = time.time() - start_time
    print("Total Time: %s seconds" % duration)

if __name__ == "__main__":
    main()