from __future__ import division
import os
import re
import time
import dill
import string
from bs4 import BeautifulSoup
from collections import OrderedDict

class TermVector:
    def __init__(self, tf, pos):
        self.tf = tf
        self.pos = pos

def unpickler(file):
    with open(file, 'rb') as f:
        return dill.load(f)

def parseCatalog(file):
    catalog = {}
    if not os.path.exists(file):
        return catalog
    with open(file, 'r') as f:
        for line in f:
            content = line.strip().split(',')
            if len(content) >= 2:
                # catalog[TermID] = [Offset, Length]
                catalog[content[0]] = content[1:]
    return catalog

def queryMaker():
    """Parses cran.qry.xml to extract query data."""
    query_file = 'cran.qry.xml'
    queries = []
    if not os.path.exists(query_file):
        print("Error: cran.qry.xml not found!")
        return queries

    with open(query_file, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f.read(), 'xml')
        query_nodes = soup.find_all(['top', 'query', 'doc', 'DOC'])
        
        for i, node in enumerate(query_nodes, start=1):
            num_tag = node.find(['num', 'docno', 'DOCNO'])
            q_id = num_tag.text.strip() if num_tag else str(i)
            
            text_tag = node.find(['title', 'text', 'TEXT'])
            q_text = text_tag.text.strip() if text_tag else ""
            
            clean_text = re.sub(r'[\-\.\"\s]+', ' ', q_text).strip()
            queries.append((q_id, clean_text))
    return queries

def queryProcessor(query_text):
    """Tokenizes and removes stopwords while preserving word order."""
    stoplist_path = 'stoplist.txt'
    if os.path.exists(stoplist_path):
        with open(stoplist_path, "r") as sfile:
            stopWords = set(line.strip().lower() for line in sfile)
    else:
        stopWords = set()

    # Regex preserves internal periods (e.g., '98.6')
    tokens = re.findall(r'\w+(?:\.\w+)*', query_text.lower())
    
    keywords = [t for t in tokens if t not in stopWords]
    return keywords

def getInfo(key, catalog, termMap, docMap):
    """Retrieves positional postings from the Unstemmed Index."""
    # 1. Look up TermID - Ensure key is lowercase
    termID = termMap.get(key.lower())
    
    if termID is None:
        # This is where your code is currently failing
        # print(f"Word not found in termMap: {key}") 
        return None, None
        
    # 2. Get offset from catalog using the ID string
    cat_entry = catalog.get(str(termID))
    if not cat_entry:
        return None, None
    
    offset = cat_entry[0]
    
    try:
        with open("Files/Unstemmed/invertedFile0.txt", 'r') as indexFile:
            indexFile.seek(int(offset))
            line = indexFile.readline()
        
        header, data = line.split(':')
        h_parts = header.split(',')
        df, ttf = h_parts[1], h_parts[2]
        
        docDict = OrderedDict()
        for item in data.strip().split(';'):
            if not item: continue
            parts = item.split(',')
            docID_internal = int(parts[0])
            doc_no = docMap.get(docID_internal)
            tf = int(parts[1])
            pos = [int(e) for e in parts[2:]]
            docDict[doc_no] = TermVector(tf, pos)
            
        return {key: docDict}, {key: [df, ttf]}
    except Exception as e:
        print(f"Error reading index for {key}: {e}")
        return None, None

def getParameters(query_text, qNo):
    keywords = queryProcessor(query_text)
    print(f"Query {qNo} keywords: {keywords}") # DEBUG
    termVector = OrderedDict()
    termStats = OrderedDict()
    
    for word in keywords:
        word_clean = word.lower().strip()
        invList, keyInfo = getInfo(word_clean, catalog, termMap, docMap)
        if invList:
            print(f"  Found {word_clean} in index!") # DEBUG
            termVector.update(invList)
            termStats.update(keyInfo)
    
    pickle_dir = 'Unstemmed/Pickles'
    os.makedirs(pickle_dir, exist_ok=True)
    
    with open(f'{pickle_dir}/termStats_Proximity_{qNo}.p', 'wb') as f:
        dill.dump(termStats, f)
    with open(f'{pickle_dir}/termVector_Proximity_{qNo}.p', 'wb') as f:
        dill.dump(termVector, f)

# --- EXECUTION ---
if __name__ == "__main__":
    start_time = time.time()
    
    print("Loading Unstemmed Index data for Proximity...")
    docInfo = unpickler('Unstemmed/Pickles/docInfo.p')
    catalog = parseCatalog('Unstemmed/catalogFile.txt')
    termMap = unpickler('Unstemmed/Pickles/termMap.p')
    docMap = unpickler('Unstemmed/Pickles/docMap.p')

    queries = queryMaker()
    print(f"Processing {len(queries)} queries for Unstemmed Proximity...")

    for qID, qText in queries:
        getParameters(qText, qID)
        print(f"Created Proximity termVector for Unstemmed Query {qID}")

    total_time = time.time() - start_time
    print(f"Total Time: {time.strftime('%H:%M:%S', time.gmtime(total_time))}")