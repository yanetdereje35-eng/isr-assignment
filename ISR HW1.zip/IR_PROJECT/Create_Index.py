from elasticsearch import Elasticsearch
import re
import time

es = Elasticsearch(
    "http://127.0.0.1:9200",
    basic_auth=("elastic", "YOUR_PASSWORD")
)

file_path = "cran.all.1400.xml"

start_time = time.time()

with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

doc_id = None
text = ""
count = 0

for line in lines:
    line = line.strip()

    # If line starts with a number → new document
    if re.match(r"^\d+", line):

        # save previous doc
        if doc_id is not None:
            es.index(index="index1", id=doc_id, body={"text": text.strip()})
            count += 1
            print(f"Indexed {count} documents")

        # start new doc
        parts = line.split(" ", 1)
        doc_id = parts[0]
        text = parts[1] if len(parts) > 1 else ""

    else:
        text += " " + line

if doc_id is not None:
    es.index(index="index1", id=doc_id, body={"text": text.strip()})
    count += 1   
print("DONE")
print(f"Total documents indexed: {count}")
print("Total time:", time.time() - start_time)
