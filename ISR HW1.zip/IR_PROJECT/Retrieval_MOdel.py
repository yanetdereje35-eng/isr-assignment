from elasticsearch import Elasticsearch
import math

# connect to Elasticsearch
es = Elasticsearch(
    "http://localhost:9200",
    basic_auth=("elastic", "YOUR_PASSWORD")
)

INDEX = "index1"
TOTAL_DOCS = 84678  # approximate corpus size (you already used this before)


# -----------------------------
# Helper: Get documents for a query
# -----------------------------
def get_candidate_docs(query):
    res = es.search(
        index=INDEX,
        size=100,
        query={
            "match": {
                "text": query
            }
        }
    )
    return res["hits"]["hits"]


# -----------------------------
# MODEL 1: BM25 (Elasticsearch-based ranking already approximated)
# -----------------------------
def bm25_rank(query, query_id):
    results = get_candidate_docs(query)

    output = []
    rank = 1

    for doc in results[:100]:
        docno = doc["_id"]
        score = doc["_score"]

        line = f"{query_id} Q0 {docno} {rank} {score} Exp"
        output.append(line)
        rank += 1

    return output


# -----------------------------
# MODEL 2: TF-IDF (simple approximation using ES score)
# -----------------------------
def tfidf_rank(query, query_id):
    results = get_candidate_docs(query)

    output = []
    rank = 1

    for doc in results[:100]:
        docno = doc["_id"]

        # approximate TF-IDF using score normalization
        score = math.log(1 + doc["_score"])

        line = f"{query_id} Q0 {docno} {rank} {score} Exp"
        output.append(line)
        rank += 1

    return output


# -----------------------------
# MAIN FUNCTION (called by Query_Processing.py)
# -----------------------------
def rank_documents(es_client, query_id, query_text):

    # You can switch model here:
    return bm25_rank(query_text, query_id)

    # OR test TF-IDF:
    # return tfidf_rank(query_text, query_id)