from collections import defaultdict

# -----------------------------
# Load relevance judgments (cranqrel.trec)
# -----------------------------
def load_qrels(file_path):
    qrels = defaultdict(set)

    with open(file_path, "r") as f:
        for line in f:
            parts = line.split()
            qid = parts[0]
            docid = parts[2]
            relevance = int(parts[3])

            if relevance > 0:
                qrels[qid].add(docid)

    return qrels


# -----------------------------
# Load system results
# -----------------------------
def load_results(file_path):
    results = defaultdict(list)

    with open(file_path, "r") as f:
        for line in f:
            parts = line.split()
            qid = parts[0]
            docid = parts[2]

            results[qid].append(docid)

    return results


# -----------------------------
# Precision@10
# -----------------------------
def precision_at_10(results, qrels):
    precisions = []

    for qid in results:
        retrieved = results[qid][:10]
        relevant = qrels[qid]

        if len(retrieved) == 0:
            continue

        hits = 0
        for doc in retrieved:
            if doc in relevant:
                hits += 1

        precisions.append(hits / 10)

    return sum(precisions) / len(precisions) if precisions else 0


# -----------------------------
# Average Precision (per query)
# -----------------------------
def average_precision(retrieved, relevant):
    hits = 0
    score = 0.0

    for i, doc in enumerate(retrieved):
        if doc in relevant:
            hits += 1
            score += hits / (i + 1)

    if hits == 0:
        return 0

    return score / len(relevant)


# -----------------------------
# Mean Average Precision (MAP)
# -----------------------------
def mean_average_precision(results, qrels):
    ap_values = []

    for qid in results:
        ap = average_precision(results[qid], qrels[qid])
        ap_values.append(ap)

    return sum(ap_values) / len(ap_values) if ap_values else 0


# -----------------------------
# MAIN RUN
# -----------------------------
if __name__ == "__main__":
    qrels = load_qrels("cranqrel.trec.txt")
    results = load_results("results.txt")

    p10 = precision_at_10(results, qrels)
    map_score = mean_average_precision(results, qrels)

    print("Precision@10:", p10)
    print("MAP:", map_score)


