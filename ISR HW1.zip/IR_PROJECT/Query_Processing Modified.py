
from elasticsearch import Elasticsearch
import xml.etree.ElementTree as ET
from Retrieval_MOdel import rank_documents

# connect to Elasticsearch
es = Elasticsearch(
    "http://localhost:9200",
    basic_auth=("elastic", "YOUR_PASSWORD")
)

# query file
file_path = "cran.qry.xml"

# parse XML queries
tree = ET.parse(file_path)
root = tree.getroot()

results_output = []

for top in root.findall("top"):
    query_id = top.find("num").text.strip()
    query_text = top.find("title").text.strip()

    print(f"Processing Query {query_id}")

    # call retrieval model (we will build this next)
    ranked_docs = rank_documents(es, query_id, query_text)

    # ranked_docs must return formatted output lines
    results_output.extend(ranked_docs)

# write final results file
with open("results.txt", "w") as f:
    for line in results_output:
        f.write(line + "\n")

print("Done! Results saved to results.txt")