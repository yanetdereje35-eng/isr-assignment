import pandas as pd
from rank_bm25 import BM25Okapi
import re

# Exact file names from your sidebar
PATH_TO_DOCS = 'cran.all.1400'
PATH_TO_QRYS = 'cran.qry'
PATH_TO_QREL = 'cranqrel.trec'

def parse_cran_file(filepath):
    print(f"Reading file: {filepath}")
    with open(filepath, 'r') as f:
        content = f.read()
    
    # This splits the file by the .I marker and captures the ID
    items = re.split(r'\.I\s+(\d+)', content)
    parsed = []
    
    # items[0] is empty, then [ID1, Content1, ID2, Content2...]
    for i in range(1, len(items), 2):
        item_id = int(items[i])
        item_content = items[i+1]
        
        # Look for text after the .W marker
        if '.W' in item_content:
            text = item_content.split('.W', 1)[1].strip()
        else:
            # Fallback: take everything after the first line
            text = " ".join(item_content.strip().split('\n')[1:])

        # Clean up any remaining markers (.A, .B, .T)
        text = re.split(r'\.[ABT]', text)[0].strip()
        text = " ".join(text.split()) # Remove extra whitespace
        
        if text:
            parsed.append({"id": item_id, "text": text})
            
    return parsed

def load_labels(qrel_path):
    print(f"Reading relevance file: {qrel_path}")
    labels = {}
    try:
        with open(qrel_path, 'r') as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 3:
                    q_id, d_id = int(parts[0]), int(parts[2])
                    if q_id not in labels:
                        labels[q_id] = set()
                    labels[q_id].add(d_id)
    except Exception:
        pass
    return labels

def main():
    docs = parse_cran_file(PATH_TO_DOCS)
    queries = parse_cran_file(PATH_TO_QRYS)
    relevance_map = load_labels(PATH_TO_QREL)
    
    if len(docs) == 0 or len(queries) == 0:
        print(f"Error: Found {len(docs)} docs and {len(queries)} queries.")
        return

    print(f"Success! Found {len(docs)} documents and {len(queries)} queries.")

    # BM25 Setup
    tokenized_corpus = [d['text'].lower().split() for d in docs]
    bm25 = BM25Okapi(tokenized_corpus)

    feature_rows = []
    print("Generating matrix...")
    for q in queries:
        q_tokens = q['text'].lower().split()
        scores = bm25.get_scores(q_tokens)
        relevant_docs = relevance_map.get(q['id'], set())

        for i, doc in enumerate(docs):
            feature_rows.append({
                "query_id": q['id'],
                "doc_id": doc['id'],
                "BM25": round(scores[i], 4),
                "Label": 1 if doc['id'] in relevant_docs else 0
            })

    df = pd.DataFrame(feature_rows)
    df.to_csv("feature_matrix_cranfield.csv", index=False)
    print(f"DONE! Saved {len(df)} rows to feature_matrix_cranfield.csv")

if __name__ == "__main__":
    main()